/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test; // Importa a anotação @Test do JUnit para marcar métodos como testes
import static org.junit.jupiter.api.Assertions.*; // Importa métodos estáticos de Assertions para verificação em testes

public class BaralhoTest { // Declaração da classe de testes BaralhoTest

    @Test // Anotação que indica que o método é um teste
    public void testDistribuirCarta() {
        Baralho baralho = new Baralho(); // Cria um objeto Baralho para testar
        assertNotNull(baralho.distribuirCarta()); // Verifica se a carta distribuída não é nula
    }

}

