/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */
/**
 *
 * @author Vitor Hugo
 */
public class Jogador {
    private String nome;
    private int hp;

    public Jogador(String nome, EstrategiaDano hp) {
        this.nome = nome;
     
    }

    public void reduzirPontosDeVida(int dano) {
        this.hp -= dano;
        System.out.println(this.nome + " tomou " + dano + " de dano e agora tem " + this.hp + " de HP.");
    }

    public void adicionarPontosDeVida(int vida) {
        this.hp += vida;
        System.out.println(this.nome + " ganhou " + vida + " de vida e agora tem " + this.hp + " de HP.");
    }

    public String getNome() {
        return nome;
    }

    public int getHp() {
        return hp;
    }

    public void setHp(int hp) {
        this.hp = hp;
    }

    short getPontosDeVida() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

   
}



