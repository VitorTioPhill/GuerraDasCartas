/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test; // Importa a anotação @Test do JUnit para marcar métodos como testes
import static org.junit.jupiter.api.Assertions.*; // Importa métodos estáticos de Assertions para verificação em testes

public class GuerraDasCartasTest { // Declaração da classe de testes GuerraDasCartasTest
        EstrategiaDano estrategiaPadrao = new EstrategiaDanoPadrao();
        EstrategiaDano estrategiaRefletido = new EstrategiaDanoRefletido();
    
    
    @Test // Anotação que indica que o método é um teste
    public void testarComparacaoDeCartas() {
        // Aqui você implementaria os testes para comparar as cartas
        // Exemplo de implementação:
        Carta carta1 = new Carta("Carta A", "Criatura", "Planícies Azuis", 5);
        Carta carta2 = new Carta("Carta B", "Criatura", "Milharais", 3);

        assertTrue(carta1.getPoder() > carta2.getPoder()); // Exemplo de comparação, verifica se o poder da carta1 é maior que o da carta2
        assertFalse(carta2.getPoder() > carta1.getPoder()); // Exemplo de comparação, verifica se o poder da carta2 não é maior que o da carta1
    }

    @Test // Anotação que indica que o método é um teste
    public void testarAtualizacaoPontosDeVida() {
        Jogador jogador1 = new Jogador("Jogador 1", estrategiaPadrao); // Cria um jogador 1
        Jogador jogador2 = new Jogador("Jogador 2", estrategiaPadrao); // Cria um jogador 2
        
        // Simulando uma rodada onde jogador1 ganha
        Carta cartaJogador1 = new Carta("Carta A", "Criatura", "Planícies Azuis", 5); // Carta do jogador 1
        Carta cartaJogador2 = new Carta("Carta B", "Criatura", "Milharais", 3); // Carta do jogador 2
        
        // Simulação da comparação de cartas
        if (cartaJogador1.getPoder() > cartaJogador2.getPoder()) {
            int dano = cartaJogador1.getPoder() - cartaJogador2.getPoder();
            jogador2.reduzirPontosDeVida(dano); // Jogador 2 perde pontos de vida
        } else if (cartaJogador1.getPoder() < cartaJogador2.getPoder()) {
            int dano = cartaJogador2.getPoder() - cartaJogador1.getPoder();
            jogador1.reduzirPontosDeVida(dano); // Jogador 1 perde pontos de vida
        }
        
        assertEquals(20, jogador1.getPontosDeVida()); // Verifica se os pontos de vida do jogador 1 são 20
        assertEquals(17, jogador2.getPontosDeVida()); // Verifica se os pontos de vida do jogador 2 são 17
    }
}
