/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */

import org.junit.jupiter.api.Test; // Importa a anotação @Test do JUnit para marcar métodos como testes
import static org.junit.jupiter.api.Assertions.*; // Importa métodos estáticos de Assertions para verificação em testes

public class CartaTest { // Declaração da classe de testes CartaTest

    @Test // Anotação que indica que o método é um teste
    public void testGetNome() {
        Carta carta = new Carta("Carta Teste", "Tipo Teste", "Terreno Teste", 3); // Cria uma carta de teste
        assertEquals("Carta Teste", carta.getNome()); // Verifica se o método getNome() retorna "Carta Teste"
    }

}


