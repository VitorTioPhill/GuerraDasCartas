/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */

/**
 *
 * @author Kailane
 */
// Interface para definir as estratégias de cálculo de dano
interface EstrategiaDano {
    void aplicarDano(int dano, Jogador jogador, Jogador jogadorB);
}
