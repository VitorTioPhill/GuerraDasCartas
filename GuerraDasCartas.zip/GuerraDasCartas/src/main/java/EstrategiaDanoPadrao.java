/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Kailane
 */
// Implementação da estratégia de dano padrão
class EstrategiaDanoPadrao implements EstrategiaDano {
    @Override
    public void aplicarDano(int dano, Jogador jogador, Jogador jogadorB) {
        jogador.reduzirPontosDeVida(dano);
    }
}
