/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vitor Hugo
 * 
 * Sobre o funcionamento do jogo:
 * 1- Um jogo de cartas colecionáveis com diversas criaturas e personagens do universo de Hora de Aventura.
 * 2 - Combina elementos de estratégia, sorte e blefe para criar uma experiência empolgante e desafiadora.
 * 3 - Os jogadores colecionam cartas, constroem decks poderosos e duelam entre si para conquistar a Terra de Ooo.
 */
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Scanner;
import java.util.Random;
import java.util.Set;

public class GuerraDasCartas {

    public static void main(String[] args) {
        
        
        EstrategiaDano estrategiaPadrao = new EstrategiaDanoPadrao();
        EstrategiaDano estrategiaRefletido = new EstrategiaDanoRefletido();

        
        
        // Cria um baralho inicial
        List<Carta> baralho = criarBaralhoInicial();
        Set<Carta> cartasUtilizadas = new HashSet<>(baralho);

        Scanner scanner = new Scanner(System.in);
        Random random = new Random();

        int hpJogador1 = 20;
        int hpJogador2 = 20;

        int rodada = 1;

        while (hpJogador1 > 0 && hpJogador2 > 0) {
            System.out.println("--- Rodada " + rodada + " ---");
            System.out.println("Jogador 1 HP: " + hpJogador1);
            System.out.println("Jogador 2 HP: " + hpJogador2);

            // Verifica se há cartas suficientes para ambos os jogadores
            if (baralho.size() < 2) {
                System.out.println("Adicionando novas cartas ao baralho...");
                baralho.addAll(criarCartasAleatorias(cartasUtilizadas));
                cartasUtilizadas.addAll(baralho);
            }

            // Mostra as opções de cartas para o Jogador 1
            System.out.println("Opcoes disponiveis para Jogador 1:");
            exibirCartas(baralho);

            // Jogador 1 seleciona uma carta
            int escolhaJogador1 = selecionarCarta(scanner, baralho);

            // Remove a carta escolhida do baralho do Jogador 1
            Carta cartaJogador1 = baralho.remove(escolhaJogador1);

            // Mostra as opções de cartas para o Jogador 2
            System.out.println("Opcoes disponiveis para Jogador 2:");
            exibirCartas(baralho);

            // Jogador 2 seleciona uma carta
            int escolhaJogador2 = selecionarCarta(scanner, baralho);

            // Remove a carta escolhida do baralho do Jogador 2
            Carta cartaJogador2 = baralho.remove(escolhaJogador2);

            System.out.println("Jogador 1 joga: " + cartaJogador1);
            System.out.println("Jogador 2 joga: " + cartaJogador2);

            if (cartaJogador1.getPoder() > cartaJogador2.getPoder()) {
                int dano = cartaJogador1.getPoder() - cartaJogador2.getPoder();
                hpJogador2 -= dano;
                System.out.println("Jogador 1 venceu a rodada e causou " + dano + " pontos de dano ao Jogador 2.");
            } else if (cartaJogador1.getPoder() < cartaJogador2.getPoder()) {
                int dano = cartaJogador2.getPoder() - cartaJogador1.getPoder();
                hpJogador1 -= dano;
                System.out.println("Jogador 2 venceu a rodada e causou " + dano + " pontos de dano ao Jogador 1.");
            } else {
                System.out.println("Rodada empatada!");
            }

            rodada++;

            pausarPorSegundos(2); // Método para pausar a execução por alguns segundos

            System.out.println();
        }

        if (hpJogador1 <= 0) {
            System.out.println("Jogador 2 venceu o jogo!");
        } else {
            System.out.println("Jogador 1 venceu o jogo!");
        }

        scanner.close();
    }

    private static List<Carta> criarBaralhoInicial() {
        List<Carta> baralho = new ArrayList<>();
        baralho.add(new Carta("Husker Knights", "Criatura", "Milharais", 5));
        baralho.add(new Carta("Cool Dog", "Criatura", "Terras Arenosas", 3));
        baralho.add(new Carta("Mighty Dragon", "Criatura", "Planicies Azuis", 7));
        baralho.add(new Carta("Ancient Wizard", "Feitico", "Pantanos Inuteis", 4));
        baralho.add(new Carta("Fire Elemental", "Criatura", "Vulcoes Furiosos", 6));
        baralho.add(new Carta("Sorceress of the Seas", "Criatura", "Oceano Profundo", 8));
        baralho.add(new Carta("Nature's Guardian", "Criatura", "Floresta Antiga", 9));
        return baralho;
    }

    private static List<Carta> criarCartasAleatorias(Set<Carta> cartasUtilizadas) {
        List<Carta> novasCartas = new ArrayList<>();
        List<Carta> possiveisCartas = new ArrayList<>();
        
        possiveisCartas.add(new Carta("Goblin", "Criatura", "Planícies Azuis", 2));
        possiveisCartas.add(new Carta("Inferno Titan", "Criatura", "Vulcoes Furiosos", 10));
        possiveisCartas.add(new Carta("Dark Ritual", "Feitico", "Pantanos Inuteis", 5));
        possiveisCartas.add(new Carta("Archangel Avacyn", "Criatura", "Floresta Antiga", 7));
        possiveisCartas.add(new Carta("Lightning Bolt", "Feitico", "Terras Arenosas", 3));
        possiveisCartas.add(new Carta("Serra Angel", "Criatura", "Planicies Azuis", 4));

        Random random = new Random();
        while (novasCartas.size() < 6 && possiveisCartas.size() > 0) {
            int index = random.nextInt(possiveisCartas.size());
            Carta carta = possiveisCartas.get(index);
            if (!cartasUtilizadas.contains(carta)) {
                novasCartas.add(carta);
                cartasUtilizadas.add(carta);
            }
            possiveisCartas.remove(index);
        }
        return novasCartas;
    }

    private static void exibirCartas(List<Carta> cartas) {
        for (int i = 0; i < cartas.size(); i++) {
            System.out.println(i + ": " + cartas.get(i));
        }
    }

    private static int selecionarCarta(Scanner scanner, List<Carta> baralho) {
        System.out.println("Escolha uma carta (0-" + (baralho.size() - 1) + "): ");
        int escolha = scanner.nextInt();
        while (escolha < 0 || escolha >= baralho.size()) {
            System.out.println("Opcao invalida. Escolha uma carta valida (0-" + (baralho.size() - 1) + "): ");
            escolha = scanner.nextInt();
        }
        return escolha;
    }

    private static void pausarPorSegundos(int segundos) {
        try {
            Thread.sleep(segundos * 1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }
}






