/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vitor Hugo
 */
import java.util.ArrayList; // Importa a classe ArrayList, que será usada para armazenar as cartas no baralho
import java.util.Collections; // Importa a classe Collections para operações com coleções, como embaralhar
import java.util.List; // Importa a interface List, que define uma lista de elementos

public class Baralho { // Declaração da classe Baralho
    private List<Carta> cartas; // Lista de cartas que compõem o baralho

    // Construtor da classe Baralho que inicializa a lista de cartas e adiciona cartas ao baralho
    public Baralho() {
        cartas = new ArrayList<>(); // Inicializa a lista de cartas como um ArrayList vazio
        adicionarCartas(); // Chama o método para adicionar cartas ao baralho
        Collections.shuffle(cartas); // Embaralha as cartas do baralho
    }

    // Método privado para adicionar cartas ao baralho
    private void adicionarCartas() {
        // Adicionando cartas Criaturas
        cartas.add(new Carta("Husker Knights", "Criatura", "Milharais", 5)); // Adiciona a carta "Husker Knights"
        cartas.add(new Carta("Cool Dog", "Criatura", "Terras Arenosas", 3)); // Adiciona a carta "Cool Dog"
        cartas.add(new Carta("Immortal Maize Walker", "Criatura", "Milharais", 4)); // Adiciona a carta "Immortal Maize Walker"
        cartas.add(new Carta("Pig", "Criatura", "Planícies Azuis", 2)); // Adiciona a carta "Pig"
        cartas.add(new Carta("Ancient Scholar", "Criatura", "Planícies Azuis", 6)); // Adiciona a carta "Ancient Scholar"

        // Adicionando cartas Construções
        cartas.add(new Carta("Corn Dome", "Construção", "Milharais", 3)); // Adiciona a carta "Corn Dome"
        cartas.add(new Carta("Field of Nightmares", "Construção", "Pântanos Inúteis", 4)); // Adiciona a carta "Field of Nightmares"

        // Adicionando cartas Feitiços
        cartas.add(new Carta("Algebraic!", "Feitiço", "Terras Arenosas", 5)); // Adiciona a carta "Algebraic!"
    }

    // Método para distribuir (remover e retornar) uma carta do topo do baralho
    public Carta distribuirCarta() {
        if (!cartas.isEmpty()) { // Verifica se ainda há cartas no baralho
            return cartas.remove(cartas.size() - 1); // Remove e retorna a última carta da lista
        }
        return null; // Retorna null se o baralho estiver vazio
    }

    // Método para verificar se ainda há cartas no baralho
    public boolean temCartas() {
        return !cartas.isEmpty(); // Retorna true se a lista de cartas não estiver vazia, caso contrário, false
    }
}


