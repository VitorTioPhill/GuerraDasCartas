/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Vitor Hugo
 */
public class Carta { // Declaração da classe Carta
    private String nome; // Atributo que armazena o nome da carta
    private String tipo; // Atributo que armazena o tipo da carta (Criatura, Construção, Feitiço)
    private String terreno; // Atributo que armazena o terreno associado à carta (Planícies Azuis, Milharais, Terras Arenosas, Pântanos Inúteis)
    private int poder; // Atributo que armazena o poder da carta

    // Construtor da classe Carta que inicializa os atributos nome, tipo, terreno e poder
    public Carta(String nome, String tipo, String terreno, int poder) {
        this.nome = nome; // Inicializa o nome da carta
        this.tipo = tipo; // Inicializa o tipo da carta
        this.terreno = terreno; // Inicializa o terreno da carta
        this.poder = poder; // Inicializa o poder da carta
    }

    // Método getter para obter o nome da carta
    public String getNome() {
        return nome;
    }

    // Método getter para obter o tipo da carta
    public String getTipo() {
        return tipo;
    }

    // Método getter para obter o terreno da carta
    public String getTerreno() {
        return terreno;
    }

    // Método getter para obter o poder da carta
    public int getPoder() {
        return poder;
    }

    // Método toString para representar a carta como uma string
    @Override
    public String toString() {
        return nome + " (" + tipo + ") - " + terreno + " - Poder: " + poder; // Retorna uma representação em string da carta
}
}


